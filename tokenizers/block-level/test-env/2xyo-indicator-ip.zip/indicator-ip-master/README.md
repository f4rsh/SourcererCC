indicator-ip (for unity)
=======================

indicator-ip displays your public IP address.

![indicator-ip on Ubuntu 12.10](http://img824.imageshack.us/img824/9011/indicatorip.png "indicator-ip")


Installation
-----------

	$ sudo add-apt-repository ppa:2xyo/indicator-ip
	$ sudo ap-get install indicator-ip


[![Build Status](https://secure.travis-ci.org/2xyo/indicator-ip.png)](http://travis-ci.org/2xyo/indicator-ip)
