#!/usr/bin/env python
# -*- coding: utf-8 -*-

def test_a():
   assert 'a' == 'a'
