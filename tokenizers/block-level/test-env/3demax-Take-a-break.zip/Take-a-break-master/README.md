Take-a-break
============

Just another take-a-break app, intended to be easy to use and to hack


Screenshots
-----------

![Pause screen](http://3demax.github.com/Take-a-break/screenshots/pause_screen_thumb.png)

Usage
-----

	python take-a-break.py
